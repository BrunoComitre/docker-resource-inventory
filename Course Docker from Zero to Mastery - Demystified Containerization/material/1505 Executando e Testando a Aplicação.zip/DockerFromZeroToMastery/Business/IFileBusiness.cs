﻿using RestWithASPNETUdemy.Model;

namespace RestWithASPNETUdemy.Business
{
    public interface IFileBusiness
    {
         byte[] GetPDFFile();
    }
}
