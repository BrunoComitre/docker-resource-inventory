﻿using System.Runtime.Serialization;

namespace RestWithASPNETUdemy.Model
{
    public class UserVO
    {
        public string Login { get; set; }
        public string AccessKey { get; set; }
    }
}
